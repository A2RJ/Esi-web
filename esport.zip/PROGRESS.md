# Roles
- Pendaftaran
- - tabel user (data pribadi)
- - pilih role dan ketika sudah selesai, klik tombol "Next" untuk mengisi data diri berdasarkan role yang dipilih

- jika dia user
- - user_team_histories = tim mana saja yg pernah dia join
- - user_event_histories = event mana saja yg pernah dia join

- semua user dapat membuat event (event_user_id = id_user)
- - event_teams = semua tim yg terdaftar di event
- - event_winners = tim yg menang event (1 sampai 3 tim)