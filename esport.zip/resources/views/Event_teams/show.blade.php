@extends('layouts.dashboard')
@section('title', 'Event_teams')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>  {{ $event_teams->id_event_teams }}</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="/anggota/Event_teams/index" title="Go back"> Go back<i class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>id_event_teams:</strong>
                    {{ $event_teams->id_event_teams }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>squad_id:</strong>
                    {{ $event_teams->squad_id }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>isfree:</strong>
                    {{ $event_teams->isfree }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>ispaid:</strong>
                    {{ $event_teams->ispaid }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>created_at:</strong>
                    {{ $event_teams->created_at }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>updated_at:</strong>
                    {{ $event_teams->updated_at }}
                </div>
            </div>
            
    </div>
@endsection