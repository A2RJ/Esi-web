@extends('layouts.dashboard')
@section('title', 'Squad_inv_players')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>  {{ $squad_inv_players->id_squad_inv_player }}</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="Squad_inv_players/index" title="Go back"> Go back<i class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>id_squad_inv_player:</strong>
                    {{ $squad_inv_players->id_squad_inv_player }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>squad_id:</strong>
                    {{ $squad_inv_players->squad_id }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>player_id:</strong>
                    {{ $squad_inv_players->player_id }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>status:</strong>
                    {{ $squad_inv_players->status }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>created_at:</strong>
                    {{ $squad_inv_players->created_at }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>updated_at:</strong>
                    {{ $squad_inv_players->updated_at }}
                </div>
            </div>
            
    </div>
@endsection