
<?php $__env->startSection('title', 'Squads'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('deleteFromSquad')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Daftar player</h4>
                <p class="card-description">
                    Daftar player
                </p>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <Th>#</th>
                                <Th>User</th>
                                <Th>Squad</th>
                                <Th>Game</th>
                                <Th>Sebagai player</th>
                                <Th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->ingame_name); ?></td>
                                <td><?php echo e($data->squad ? $data->squad->squad_name : 'Tidak join squad'); ?></td>
                                <td><?php echo e($data->game->game_name); ?></td>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="/home/player/<?php echo e($data->id_player); ?>" title="show" class="badge badge-info">Show</a>
                                        <?php if($data->id_player !== $data->squad->squad_leader): ?>
                                        <a href="/squads/destroyFromSquad/<?php echo e($data->id_player); ?>" class="badge badge-danger">Delete from squad</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Invite player</h4>
                <p class="card-description">
                    Menu untuk invite player
                </p>
                <a class="btn btn-primary" href="/squad_inv_players/create/<?php echo e($id); ?>" title="Create a data"> <i class="fas fa-plus-circle"></i>
                    Create
                </a>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <Th>#</th>
                                <Th>Squad</th>
                                <Th>Player</th>
                                <Th>Status</th>
                                <Th>Diinvite Pada</th>
                                <Th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $squad_inv_players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><?php echo e($data->ingame_name); ?></td>
                                <td><?php echo e($data->status == 0 ? 'Waiting' : 'Accepted'); ?></td>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="/squad_inv_players/destroy/<?php echo e($data->id_squad_inv_player); ?>" class="badge badge-danger"><?php echo e($data->status ? 'Delete' : 'Batal'); ?></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Request join squad</h4>
                <p class="card-description">
                    Daftar request join squad dari player
                </p>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <Th>#</th>
                                <Th>Player</th>
                                <Th>Squad</th>
                                <Th>Status</th>
                                <Th>Diajukan Pada</th>
                                <Th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $request_squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->ingame_name); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><?php echo e($data->status ? 'Accepted' : 'Waiting'); ?></td>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <?php if ($data->status) { ?>
                                            <a href="/request_squads/destroy/<?php echo e($data->id_request_squad); ?>" class="badge badge-danger">Delete</a>
                                        <?php } else { ?>
                                            <a href="/request_squads/terima/<?php echo e($data->id_request_squad); ?>" title="terima" class="badge badge-info">Terima</a>
                                            <a href="/request_squads/destroy/<?php echo e($data->id_request_squad); ?>" class="badge badge-danger">Tolak</a>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/squads/show.blade.php ENDPATH**/ ?>