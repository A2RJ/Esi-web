
<?php $__env->startSection('title', 'players'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add New players</h4>
                <!-- <p class="card-description">
                    <a class="btn btn-primary" href="/players" title="Go back"> Batal </a>
                </p> -->

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="/players/update/<?php echo e($players->id_player); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- <?php echo method_field('PUT'); ?> -->
                    <div class="row">
                        <div class="form-group col-sm-6">
                            <label for="game_id">Game</label>
                            <select class="form-control" name="game_id" id="game_id">
                                <option>Pilih Game</option>
                                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($game->id_game); ?>" <?php echo e($game->id_game == $players->game_id ? 'selected' : ''); ?>><?php echo e($game->game_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="ingame_name">ingame_name</label>
                            <input class="form-control" name="ingame_name" id="ingame_name" type="text" placeholder="<?php echo e($players->ingame_name); ?>" value="<?php echo e($players->ingame_name); ?>">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="ingame_id">ingame_id</label>
                            <input class="form-control" name="ingame_id" id="ingame_id" type="text" placeholder="<?php echo e($players->ingame_id); ?>" value="<?php echo e($players->ingame_id); ?>">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="player_image">player_image</label>
                            <input class="form-control" name="player_image" id="player_image" type="file">
                        </div>

                        <div class="mt-5">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/players/edit.blade.php ENDPATH**/ ?>