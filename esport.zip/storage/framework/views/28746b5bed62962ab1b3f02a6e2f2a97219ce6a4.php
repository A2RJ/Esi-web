
<?php $__env->startSection('title', 'ESI - Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="banner container row">
    <div class="col-sm-6 pt-5">
        <h1 class="font-weight-semibold mt-5">ESI Sumbawa</h1>
        <h4>Nusa Tenggara Barat.</h4>
        <h6 class="font-weight-normal text-muted pb-3">Simple is a simple template with a creative design that solves all your marketing and SEO queries.</h6>
    </div>
    <div class="col-sm-6">
        <img src="/landing-page/images/Group171.svg" alt="" class="img-fluid">

    </div>
</div>
<div class="content-wrapper">
    <div class="container">
        <section class="customer-feedback">
            <div class="row mt-5" id="events-section">
                <div class="col-12 text-center pb-5">
                    <h2>Daftar event</h2>
                    <h6 class="section-subtitle text-muted m-0">Berikut adalah event yang bisa kamu ikuti.</h6>
                </div>
                <!-- looping events -->
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3 col-xl-3 mb-3">
                    <a href="/home/event/<?php echo e($event->id_event); ?>">
                        <div class="card">
                            <div class="card-body p-0">
                                <div class="bg-success text-center card-contents rounded" style="background-image: url('/images/<?php echo e($event->event_image); ?>'); background-size: cover;">
                                    <div style="height: 200px;"></div>
                                </div>
                                <div class="card-details text-center pt-4">
                                    <h6 class="m-0 pb-1"><?php echo e($event->event_name); ?></h6>
                                    <p>Join <?php echo e($event->created_at->format('d, M Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($events->appends(['players' => $players->currentPage(),'squads' => $squads->currentPage(), 'managements' => $managements->currentPage()])->links()); ?>

                </div>
            </div>
            <div class="row mt-5" id="players-section">
                <div class="col-12 text-center pb-5">
                    <h2>Ayo cek player berbakat Sumbawa</h2>
                    <h6 class="section-subtitle text-muted m-0">Cek data mu dibawah iya.</h6>
                </div>
                <!-- looping users -->
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3 col-xl-3 mb-3">
                    <a href="/home/player/<?php echo e($player->id_player); ?>">
                        <div class="card">
                            <div class="card-body p-0">
                                <div class="bg-success text-center card-contents rounded" style="background-image: url('/images/<?php echo e($player->player_image); ?>'); background-size: cover;">
                                    <div style="height: 200px;"></div>
                                </div>
                                <div class="card-details text-center pt-4">
                                    <h6 class="m-0 pb-1"><?php echo e($player->ingame_name); ?></h6>
                                    <p>Join <?php echo e($player->created_at->format('d, M Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($players->appends(['squads' => $squads->currentPage(),'events' => $events->currentPage(), 'managements' => $managements->currentPage()])->links()); ?>

                </div>
            </div>
            <div class="row mt-5" id="squads-section">
                <div class="col-12 text-center pb-5">
                    <h2>Ayo cek squadmu</h2>
                    <h6 class="section-subtitle text-muted m-0">Cek data mu dibawah iya.</h6>
                </div>
                <!-- looping users -->
                <?php $__currentLoopData = $squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3 col-xl-3 mb-3">
                    <a href="/home/squad/<?php echo e($squad->id_squad); ?>">
                        <div class="card">
                            <div class="card-body p-0">
                                <div class="bg-success text-center card-contents rounded" style="background-image: url('/images/<?php echo e($squad->squad_image); ?>'); background-size: cover;">
                                    <div style="height: 200px;"></div>
                                </div>
                                <div class="card-details text-center pt-4">
                                    <h6 class="m-0 pb-1"><?php echo e($squad->squad_name); ?></h6>
                                    <p>Join <?php echo e($squad->created_at->format('d, M Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($squads->appends(['players' => $players->currentPage(),'events' => $events->currentPage(), 'managements' => $managements->currentPage()])->links()); ?>

                </div>
            </div>
            <div class="row mt-5" id="managements-section">
                <div class="col-12 text-center pb-5">
                    <h2>Butuh management?</h2>
                    <h6 class="section-subtitle text-muted m-0">Cek dibawah iya.</h6>
                </div>
                <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3 col-xl-3 mb-3">
                    <a href="/home/management/<?php echo e($management->id_management); ?>">
                        <div class="card">
                            <div class="card-body p-0">
                                <div class="bg-success text-center card-contents rounded" style="background-image: url('/images/<?php echo e($management->management_image); ?>'); background-size: cover;">
                                    <div style="height: 200px;"></div>
                                </div>
                                <div class="card-details text-center pt-4">
                                    <h6 class="m-0 pb-1"><?php echo e($management->management_name); ?></h6>
                                    <p>Join <?php echo e($management->created_at->format('d, M Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($managements->appends(['players' => $players->currentPage(),'events' => $events->currentPage(), 'squads' => $squads->currentPage()])->links()); ?>

                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/test/index.blade.php ENDPATH**/ ?>