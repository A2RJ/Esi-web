
<?php $__env->startSection('title', 'events'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Add New events</h4>
        <!-- <p class="card-description">
          <a class="btn btn-primary" href="/events" title="Go back"> Batal </a>
        </p> -->

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <strong>Whoops!</strong> There were some problems with your input.<br><br>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>

        <form action="/events/update/<?php echo e($event->id_event); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <!-- <?php echo method_field('PUT'); ?> -->
          <!-- select games -->
          <div class="form-group">
            <label for="game_id">Games</label>
            <select class="form-control" name="game_id" id="game_id">
              <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($game->id_game); ?>" <?php echo e($game->id_game == $event->game_id ? 'selected' : ''); ?>><?php echo e($game->game_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="form-group">
            <label for="event_name">Event Name</label>
            <input class="form-control" name="event_name" id="event_name" type="text" placeholder="<?php echo e($event->event_name); ?>" value="<?php echo e($event->event_name); ?>">
          </div>

          <div class="form-group">
            <label for="event_image">Event Image</label>
            <input class="form-control" name="event_image" id="event_image" type="file" placeholder="<?php echo e($event->event_image); ?>" value="<?php echo e($event->event_image); ?>">
          </div>

          <div class="form-group">
            <label for="slot">Slot</label>
            <input class="form-control" name="slot" id="slot" type="text" placeholder="<?php echo e($event->slot); ?>" value="<?php echo e($event->slot); ?>">
          </div>

          <div class="form-group">
            <label for="price">Fee/Slot</label>
            <input class="form-control" name="price" id="price" type="text" placeholder="<?php echo e($event->price); ?>" value="<?php echo e($event->price); ?>">
          </div>

          <div class="form-group">
            <label for="pricepool">Price Pool</label>
            <input class="form-control" name="pricepool" id="pricepool" type="text" placeholder="<?php echo e($event->pricepool); ?>" value="<?php echo e($event->pricepool); ?>">
          </div>

          <div class="form-group">
            <label for="isfree">Is free</label>
            <select class="form-control" name="isfree" id="isfree">
              <option value="0" <?php echo e($event->isfree == 0 ? 'selected' : ''); ?>>No</option>
              <option value="1" <?php echo e($event->isfree == 1 ? 'selected' : ''); ?>>Yes</option>
            </select>
          </div>

          <div class="form-group">
            <label for="detail">Detail</label>
            <textarea class="form-control" name="detail" id="detail" rows="3" placeholder="<?php echo e($event->detail); ?>"><?php echo e($event->detail); ?></textarea>
          </div>

          <div class="form-group">
            <label for="peraturan">Peraturan</label>
            <textarea class="form-control" name="peraturan" id="peraturan" rows="3" placeholder="<?php echo e($event->peraturan); ?>"><?php echo e($event->peraturan); ?></textarea>
          </div>

          <div class="form-group">
            <label for="start">Start</label>
            <input class="form-control" name="start" id="start" type="text" placeholder="<?php echo e($event->start); ?>" value="<?php echo e($event->start); ?>">
          </div>

          <div class="form-group">
            <label for="end">End</label>
            <input class="form-control" name="end" id="end" type="text" placeholder="<?php echo e($event->end); ?>" value="<?php echo e($event->end); ?>">
          </div>

          <div class="mt-5">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/events/edit.blade.php ENDPATH**/ ?>