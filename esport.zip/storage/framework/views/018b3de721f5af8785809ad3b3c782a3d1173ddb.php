
<?php $__env->startSection('title', 'management_inv_squads'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Invite squads</h4>
                <!-- <p class="card-description">
                    <a class="btn btn-primary" href="/management_inv_squads" title="Go back"> Batal </a>
                </p> -->

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form action="/management_inv_squads/store" method="POST" class="forms-sample">
                    <?php echo csrf_field(); ?>
                    <!-- select managements -->
                    <div class="form-group">
                        <label for="management_id">Management</label>
                        <select class="form-control" name="management_id" id="management_id">
                            <option value="">-- Pilih --</option>
                            <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($management->id_management); ?>"><?php echo e($management->management_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- looping squads -->
                    <div class="form-group">
                        <label for="squad_id">squad_id</label>
                        <select class="form-control" name="squad_id" id="squad_id">
                            <option value="">-- Pilih --</option>
                            <?php $__currentLoopData = $squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($squad->id_squad); ?>"><?php echo e($squad->squad_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/management_inv_squads/create.blade.php ENDPATH**/ ?>