
<?php $__env->startSection('title', 'request_squads'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Request join squad</h4>
                <p class="card-description">
                    Daftar request join squad dari player
                </p>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>player id</th>
                                <th>squad id</th>
                                <th>status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $request_squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->ingame_name); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><?php echo e($data->status ? 'Accepted' : 'Waiting'); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <?php if ($data->status) { ?>
                                            <a href="/request_squads/destroy/<?php echo e($data->id_request_squad); ?>" class="badge badge-danger">Delete</a>
                                        <?php } else { ?>
                                            <a href="/request_squads/terima/<?php echo e($data->id_request_squad); ?>" title="terima" class="badge badge-info">Terima</a>
                                            <a href="/request_squads/destroy/<?php echo e($data->id_request_squad); ?>" class="badge badge-danger">Tolak</a>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/request_squads/request.blade.php ENDPATH**/ ?>