
<?php $__env->startSection('title', 'squad_inv_players'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Invited from squads</h4>
                <p class="card-description">
                    <!-- Add class <code>.table-hover</code> -->
                    Menu invite player dari squad
                </p>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>squad_id</th>
                                <th>player_id</th>
                                <th>status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $squad_inv_players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><?php echo e($data->ingame_name); ?></td>
                                <td><?php echo e($data->status == 0 ? 'Accepted' : 'Waiting'); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <?php if ($data->status) { ?>
                                            <a href="/squad_inv_players/destroy/<?php echo e($data->id_squad_inv_player); ?>" class="badge badge-danger">Delete</a>
                                        <?php } else { ?>
                                            <a href="/squad_inv_players/terima/<?php echo e($data->id_squad_inv_player); ?>" title="show" class="badge badge-info">Terima</a>
                                            <a href="/squad_inv_players/destroy/<?php echo e($data->id_squad_inv_player); ?>" class="badge badge-danger">Tolak</a>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/squad_inv_players/invite.blade.php ENDPATH**/ ?>