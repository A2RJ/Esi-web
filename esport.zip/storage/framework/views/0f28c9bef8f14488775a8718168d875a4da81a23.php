
<?php $__env->startSection('title', 'users'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add New users</h4>
                <!-- <p class="card-description">
                    <a class="btn btn-primary" href="/users" title="Go back"> Batal </a>
                </p> -->

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form action="/users/store" method="POST" enctype="multipart/form-data" class="forms-sample">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-sm-6">
                            <label for="user_role">user role</label>
                            <select name="user_role" id="user_role" class="form-control">
                                <option value="player">Player</option>
                                <option value="management">Management</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="nama">fullname</label>
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="nama">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="email">email</label>
                            <input type="text" class="form-control" name="email" id="email" placeholder="email">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="password">password</label>
                            <input type="text" class="form-control" name="password" id="password" placeholder="password">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="kontak">kontak</label>
                            <input type="text" class="form-control" name="kontak" id="kontak" placeholder="kontak">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="alamat">alamat</label>
                            <input type="text" class="form-control" name="alamat" id="alamat" placeholder="alamat">
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="gender">gender</label>
                            <!-- select gender -->
                            <select class="form-control" id="gender" name="gender">
                                <option value="l">Laki-Laki</option>
                                <option value="p">Perempuan</option>
                            </select>
                        </div>

                        <div class="form-group col-sm-6">
                            <label for="user_image">user image</label>
                            <input type="text" class="form-control" name="user_image" id="user_image" placeholder="user_image">
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/users/create.blade.php ENDPATH**/ ?>