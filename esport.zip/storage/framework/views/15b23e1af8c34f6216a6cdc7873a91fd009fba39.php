
<?php $__env->startSection('title', 'Players'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>  <?php echo e($players->id_player); ?></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="Players/index" title="Go back"> Go back<i class="fas fa-backward "></i> </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>id_player:</strong>
                    <?php echo e($players->id_player); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>user_id:</strong>
                    <?php echo e($players->user_id); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>squad_id:</strong>
                    <?php echo e($players->squad_id); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>ingame_name:</strong>
                    <?php echo e($players->ingame_name); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>ingame_id:</strong>
                    <?php echo e($players->ingame_id); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>player_image:</strong>
                    <?php echo e($players->player_image); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>created_at:</strong>
                    <?php echo e($players->created_at); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>updated_at:</strong>
                    <?php echo e($players->updated_at); ?>

                </div>
            </div>
            
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/players/show.blade.php ENDPATH**/ ?>