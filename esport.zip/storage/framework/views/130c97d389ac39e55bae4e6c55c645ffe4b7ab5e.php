
<?php $__env->startSection('title', 'Add detail event'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('event_inv_teams')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Invite teams</h4>
                <p class="card-description">
                    Invite teams untuk join events mu
                </p>
                <a class="btn btn-primary" href="/event_inv_teams/create/<?php echo e($id); ?>" title="Create a data"> <i class="fas fa-plus-circle"></i>
                    Create
                </a>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Event</th>
                                <th>Squad</th>
                                <th>Status</th>
                                <th>Tanggal invite</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $event_inv_teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->event_name); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><?php echo e($data->status ? 'Diterima' : 'menunggu'); ?></td>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="/event_inv_teams/show/<?php echo e($data->id_event_inv_teams); ?>" title="show" class="badge badge-info">Show</a>
                                        <a href="/event_inv_teams/destroy/<?php echo e($data->id_event_inv_teams); ?>" class="badge badge-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('event_teams')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Event teams</h4>
                <p class="card-description">
                    Teams yang mengikuti event
                </p>
                <a class="btn btn-primary" href="/event_teams/create/<?php echo e($id); ?>" title="Create a data"> <i class="fas fa-plus-circle"></i>
                    Create
                </a>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Events</th>
                                <th>Squad</th>
                                <th>Status Pembayaran</th>
                                <th>Bukti Pembayaran</th>
                                <th>Tanggal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $event_teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->event_name); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><span class="badge badge-<?php echo e($data->ispaid == 1 ? 'success' : 'danger'); ?>"> <?php echo e($data->ispaid == 1 ? 'OKE' : 'TIDAK'); ?></span></td>
                                <?php if ($data->paid_image == null) { ?>
                                    <td>Belum Upload</td>
                                <?php } else { ?>
                                    <td><a class="badge badge-success" href="/images/<?php echo e($data->paid_image); ?>" target="_blank">Lihat Bukti</a>
                                    </td>
                                <?php } ?>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="/home/squad/<?php echo e($data->squad_id); ?>" title="show" class="badge badge-info">Show</a>
                                        <a href="/event_teams/edit/<?php echo e($data->id_event_teams); ?>" class="badge badge-warning">Edit</a>
                                        <a href="/event_teams/destroy/<?php echo e($data->id_event_teams); ?>" class="badge badge-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('event_winner')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Events Winners</h4>
                <p class="card-description">
                    Pemenang Event
                </p>
                <a class="btn btn-primary" href="/event_winner/create/<?php echo e($id); ?>" title="Create a data"> <i class="fas fa-plus-circle"></i>
                    Create
                </a>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Event</th>
                                <th>Squad</th>
                                <th>Tanggal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $event_winner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->events->event_name); ?></td>
                                <td><?php echo e($data->squads->squad_name); ?></td>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="/event_winner/show/<?php echo e($data->id_event_winner); ?>" title="show" class="badge badge-info">Show</a>
                                        <a href="/event_winner/edit/<?php echo e($data->id_event_winner); ?>" class="badge badge-warning">Edit</a>
                                        <a href="/event_winner/destroy/<?php echo e($data->id_event_winner); ?>" class="badge badge-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/events/setEvent.blade.php ENDPATH**/ ?>