
<?php $__env->startSection('title', 'management_inv_squads'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title">Invite From Management</h4>
                <p class="card-description">
                    Daftar management yang meminta untuk bergabung dengan management nya
                </p>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>management</th>
                                <th>squad_id</th>
                                <th>tanggal invite</th>
                                <th>status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $management_inv_squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->management_name); ?></td>
                                <td><?php echo e($data->squad_name); ?></td>
                                <td><?php echo e($data->created_at); ?></td>
                                <td><?php echo e($data->status ? 'Accepted' : 'Waiting'); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <?php if ($data->status) { ?>
                                            <a href="/management_inv_squads/destroy/<?php echo e($data->id_management_inv_squad); ?>" class="badge badge-danger">Delete</a>
                                        <?php } else { ?>
                                            <a href="/management_inv_squads/terima/<?php echo e($data->id_management_inv_squad); ?>" class="badge badge-info">Terima</a>
                                            <a href="/management_inv_squads/destroy/<?php echo e($data->id_management_inv_squad); ?>" class="badge badge-danger">Tolak</a>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/management_inv_squads/invite.blade.php ENDPATH**/ ?>