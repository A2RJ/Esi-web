
<?php $__env->startSection('title', 'event_winner'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add New event_winner</h4>
                <p class="card-description">
                    <a class="btn btn-primary" href="/event_winner" title="Go back"> Batal </a>
                </p>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="/event_winner/update/<?php echo e($event_winner->id_event_winner); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <!-- <?php echo method_field('PUT'); ?> -->
                    <div class="form-group">
                        <label for="id_event_winner">id_event_winner</label>
                        <input class="form-control" name="id_event_winner" id="id_event_winner" type="text" placeholder="<?php echo e($event_winner->id_event_winner); ?>" value="<?php echo e($event_winner->id_event_winner); ?>">
                    </div>

                    <!-- looping events and squads -->
                    <div class="form-group">
                        <label for="event_id">event</label>
                        <select class="form-control" name="event_id" id="event_id">
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($event->id_event); ?>" <?php echo e($event->id_event == $event_winner->id_event ? 'selected' : ''); ?>><?php echo e($event->event_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="squad_id">squad</label>
                        <select class="form-control" name="squad_id" id="squad_id">
                            <?php $__currentLoopData = $squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($squad->id_squad); ?>" <?php echo e($squad->id_squad == $event_winner->id_squad ? 'selected' : ''); ?>><?php echo e($squad->squad_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="created_at">created_at</label>
                        <input class="form-control" name="created_at" id="created_at" type="text" placeholder="<?php echo e($event_winner->created_at); ?>" value="<?php echo e($event_winner->created_at); ?>">
                    </div>

                    <div class="form-group">
                        <label for="updated_at">updated_at</label>
                        <input class="form-control" name="updated_at" id="updated_at" type="text" placeholder="<?php echo e($event_winner->updated_at); ?>" value="<?php echo e($event_winner->updated_at); ?>">
                    </div>

                    <div class="mt-5">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>

                </form>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/event_winner/edit.blade.php ENDPATH**/ ?>