
<?php $__env->startSection('title', 'management_inv_squads'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add New management_inv_squads</h4>
                <p class="card-description">
                    <a class="btn btn-primary" href="/management_inv_squads" title="Go back"> Batal </a>
                </p>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="/management_inv_squads/update/<?php echo e($management_inv_squads->id_management_inv_squad); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <!-- <?php echo method_field('PUT'); ?> -->


                    <div class="form-group">
                        <label for="id_management_inv_squad">id_management_inv_squad</label>
                        <input class="form-control" name="id_management_inv_squad" id="id_management_inv_squad" type="text" placeholder="<?php echo e($management_inv_squads->id_management_inv_squad); ?>" value="<?php echo e($management_inv_squads->id_management_inv_squad); ?>">
                    </div>

                    <div class="form-group">
                        <label for="management_id">management_id</label>
                        <input class="form-control" name="management_id" id="management_id" type="text" placeholder="<?php echo e($management_inv_squads->management_id); ?>" value="<?php echo e($management_inv_squads->management_id); ?>">
                    </div>

                   <!-- looping squads with select -->
                    <div class="form-group">
                        <label for="squad_id">squad_id</label>
                        <select class="form-control" name="squad_id" id="squad_id">
                            <option>-- Pilih Squad --</option>
                           <?php $__currentLoopData = $squads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($squad->id_squad); ?>" <?php echo e($squad->id_squad == $management_inv_squads->squad_id ? 'selected' : ''); ?>><?php echo e($squad->squad_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                   

                    <div class="form-group">
                        <label for="created_at">created_at</label>
                        <input class="form-control" name="created_at" id="created_at" type="text" placeholder="<?php echo e($management_inv_squads->created_at); ?>" value="<?php echo e($management_inv_squads->created_at); ?>">
                    </div>

                    <div class="form-group">
                        <label for="updated_at">updated_at</label>
                        <input class="form-control" name="updated_at" id="updated_at" type="text" placeholder="<?php echo e($management_inv_squads->updated_at); ?>" value="<?php echo e($management_inv_squads->updated_at); ?>">
                    </div>

                    <div class="mt-5">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>

                </form>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/management_inv_squads/edit.blade.php ENDPATH**/ ?>