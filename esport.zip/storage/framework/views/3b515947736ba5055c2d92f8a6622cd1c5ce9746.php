
<?php $__env->startSection('title', 'games'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add New games</h4>
                <!-- <p class="card-description">
                    <a class="btn btn-primary" href="/games" title="Go back"> Batal </a>
                </p> -->

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="/games/update/<?php echo e($games->id_game); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- <?php echo method_field('PUT'); ?> -->
                    <div class="form-group">
                        <label for="game_name">game_name</label>
                        <input class="form-control" name="game_name" id="game_name" type="text" placeholder="<?php echo e($games->game_name); ?>" value="<?php echo e($games->game_name); ?>">
                    </div>

                    <div class="form-group">
                        <label for="game_image">game_image</label>
                        <input class="form-control" name="game_image" id="game_image" type="file" placeholder="<?php echo e($games->game_image); ?>" value="<?php echo e($games->game_image); ?>">
                    </div>

                    <!-- looping categories -->
                    <div class="form-group">
                        <label for="game_category_id">Category</label>
                        <select class="form-control" name="game_category_id" id="game_category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id_game_category); ?>" <?php echo e($category->id_game_category == $games->game_category_id ? 'selected' : ''); ?>><?php echo e($category->game_category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mt-5">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/games/edit.blade.php ENDPATH**/ ?>