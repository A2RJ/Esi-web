
<?php $__env->startSection('title', 'managements'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <h4 class="card-title"><?php echo e(Request::is('managements') ? 'All Management' : 'My Management'); ?></h4>
                <p class="card-description">
                    Daftar Management yang terdaftar
                </p>

                <?php if(Request::is('managements/managements')): ?>
                <div class="menu">
                    <a class="btn btn-primary" href="/managements/create" title="Create a data"> <i class="fas fa-plus-circle"></i>
                        Create management
                    </a>
                    <a class="btn btn-primary" href="/management_inv_squads" title="Create a data"> <i class="fas fa-plus-circle"></i>
                        Invite squad
                    </a>
                    <a class="btn btn-primary" href="/request_managements/requestFromSquads" title="Create a data"> <i class="fas fa-plus-circle"></i>
                        Request join management
                    </a>
                </div>
                <?php endif; ?>

                <div class="table-responsive mt-4">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Management Name</th>
                                <th>Dibuat Pada</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-gray-700 dark:text-gray-400">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->management_name); ?></td>
                                <td><?php echo e($data->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="/managements/show/<?php echo e($data->id_management); ?>" title="show" class="badge badge-info">Show</a>
                                        <?php if(Request::is('managements/managements')): ?>
                                        <a href="/managements/edit/<?php echo e($data->id_management); ?>" class="badge badge-warning">Edit</a>
                                        <a href="/managements/destroy/<?php echo e($data->id_management); ?>" class="badge badge-danger">Delete</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($managements->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\esport\resources\views/managements/index.blade.php ENDPATH**/ ?>